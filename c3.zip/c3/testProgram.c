// asdf \n
int main() {
	println(37 - (3 + -43/5));
	println(1);
	int x, y = 10; // testing multiple declarations plus assignment within declarations
//	int x; // testing redeclaration
//	x = z + a + b + c + d + e; // testing greater than six errors + undeclared variables
	y = y + 1; // testing variable as expression
	println(y);
}
