/**
 * A statement assigning an expression to an already-declared variable
 */
public class AssignmentStmt extends Stmt {
	
	private int charNumber;
	private String symbol;
	private Expr expr;
	
	public AssignmentStmt(int charNumber, String symbol, Expr expr) {
		super();
		this.charNumber = charNumber;
		this.symbol = symbol;
		this.expr = expr;
	}
	
	@Override
	public String toLLVM() {
		try {
			String value = SymbolTable.getInstance().getLlvm(symbol);
			ValueAndCode valueAndCodeExpr = expr.toLLVM();
			String code = valueAndCodeExpr.getCode();
			code += "    " + "store i32 " + valueAndCodeExpr.getValue() + ", i32* " + value + "\n";
			return code;
		} catch(Exception e) {
			Compiler.printError("Character Number [" + charNumber + "] - " + e.getMessage());
			return "";
		}
	}

}
