/** An expression evaluated with two operands and their operator.
 */

public abstract class BiExpr extends Expr {

	private Expr leftOp;
	private Expr rightOp;
	private String op;

	/** Constructs a <code>BiExpr</code> with left and right operands and an operator.
	 *  @param leftOp the left operand
	 *  @param rightOp the right operand
	 *  @param op the operator
	 */
	public BiExpr(Expr leftOp, Expr rightOp, String op){
		this.leftOp = leftOp;
		this.rightOp = rightOp;
		this.op = op;
	}

	public ValueAndCode toLLVM(){
		ValueAndCode valueCodeLeftOp = leftOp.toLLVM();
		ValueAndCode valueCodeRightOp = rightOp.toLLVM();
		String value = NameAllocator.getTempAllocator().next();
		String code = valueCodeLeftOp.getCode() + valueCodeRightOp.getCode() +
				"    " + value + " = " + op + " i32 " + valueCodeLeftOp.getValue() + ", " + valueCodeRightOp.getValue() + "\n";
		return new ValueAndCode(value, code);
	}
}