/** An expression evaluated by dividing two operands.
 */

public class QuotientExpr extends BiExpr {

	/** Constructs a <code>QuotientExpr</code> with a left and right operand.
	 *  @param leftOp the left operand
	 *  @param rightOp the right operand
	 */
	public QuotientExpr(Expr leftOp, Expr rightOp){
		super(leftOp, rightOp, "sdiv");
	}
}