/**
 * An expression that's represented by a variable name
 */
public class SymbolExpr extends Expr {
	
	private int charNumber;
	private String symbol;

	public SymbolExpr(int charNumber, String symbol) {
		super();
		this.charNumber = charNumber;
		this.symbol = symbol;
	}

	@Override
	public ValueAndCode toLLVM() {
		try {
			String symbolValue = SymbolTable.getInstance().getLlvm(symbol);
			String value = NameAllocator.getTempAllocator().next();
			String code = "    " + value + " = load i32, i32* " + symbolValue + "\n";
			return new ValueAndCode(value, code);
		} catch(Exception e) {
			Compiler.printError("Character Number [" + charNumber + "] - " + e.getMessage());
			return new ValueAndCode("", "");
		}
	}

}
