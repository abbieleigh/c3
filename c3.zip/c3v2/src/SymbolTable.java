import java.util.HashMap;
import java.util.Map;

/**
 * Stores names of declared variables and their LLVM pointer name
 */
public class SymbolTable {
	
	private Map<String, String> symbols;

    private static final SymbolTable INSTANCE = new SymbolTable();

    private SymbolTable() {
    	symbols = new HashMap<String, String>();
    }

    public static SymbolTable getInstance() {
        return INSTANCE;
    }
    
    public String getLlvm(String symbol) {
    	if(!symbols.containsKey(symbol)) {
    		symbols.put(symbol, "");
    		throw new RuntimeException("Symbol [" + symbol + "] is undefined");
    	}
    	return symbols.get(symbol);
    }
    
    public void setSymbol(String symbol, String llvm) {
    	if(symbols.containsKey(symbol)) throw new RuntimeException("Symbol [" + symbol + "] is already defined.");
    	symbols.put(symbol, llvm);
    }

}
